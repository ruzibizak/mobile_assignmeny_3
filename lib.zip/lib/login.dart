import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:connectivity/connectivity.dart';
import 'package:google_sign_in/google_sign_in.dart'; // Import Google Sign-In package
import 'package:firebase_auth/firebase_auth.dart'; // Import Firebase Auth package

void main() {
  runApp(MyApp());
}

class MyApp extends StatefulWidget {
  @override
  MyAppState createState() => MyAppState();
}

class MyAppState extends State<MyApp> {
  ThemeMode _themeMode = ThemeMode.system;

  void setThemeMode(ThemeMode themeMode) {
    setState(() {
      _themeMode = themeMode;
    });
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Login Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      darkTheme: ThemeData.dark(),
      themeMode: _themeMode,
      home: Login(googleSignInProvider: GoogleSignInProvider()),
    );
  }
}

class GoogleSignInProvider {
  final GoogleSignIn _googleSignIn = GoogleSignIn();
  final FirebaseAuth _auth = FirebaseAuth.instance;

  Future<User?> signInWithGoogle() async {
    try {
      final GoogleSignInAccount? googleSignInAccount = await _googleSignIn.signIn();
      final GoogleSignInAuthentication googleSignInAuthentication = await googleSignInAccount!.authentication;

      final AuthCredential credential = GoogleAuthProvider.credential(
        accessToken: googleSignInAuthentication.accessToken,
        idToken: googleSignInAuthentication.idToken,
      );

      final UserCredential authResult = await _auth.signInWithCredential(credential);
      final User? user = authResult.user;

      return user;
    } catch (error) {
      print('Error signing in with Google: $error');
      return null;
    }
  }
}

class Login extends StatefulWidget {
  final GoogleSignInProvider googleSignInProvider;

  const Login({Key? key, required this.googleSignInProvider}) : super(key: key);

  @override
  _LoginState createState() => _LoginState();
}

class _LoginState extends State<Login> {
  final _formKey = GlobalKey<FormState>();
  late String _email;
  late String _password;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[100],
      body: Center(
        child: Container(
          width: MediaQuery.of(context).size.width * 0.8,
          padding: EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(20),
            boxShadow: [
              BoxShadow(
                color: Colors.grey.withOpacity(0.2),
                spreadRadius: 2,
                blurRadius: 5,
                offset: Offset(0, 3),
              ),
            ],
          ),
          child: Form(
            key: _formKey,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: <Widget>[
                Text(
                  'Log in',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
                SizedBox(height: 10),
                TextFormField(
                  onSaved: (value) => _email = value!,
                  validator: (value) =>
                      value?.isEmpty ?? true ? 'Please enter your email' : null,
                  decoration: InputDecoration(
                    labelText: 'Email',
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                        contentPadding: EdgeInsets.all(12),
  ),
),
SizedBox(height: 10),
TextFormField(
  obscureText: true,
  onSaved: (value) => _password = value!,
  validator: (value) =>
      value?.isEmpty ?? true ? 'Please enter your password' : null,
  decoration: InputDecoration(
    labelText: 'Password',
    border: OutlineInputBorder(
      borderRadius: BorderRadius.circular(10),
    ),
    contentPadding: EdgeInsets.all(12),
    suffixIcon: IconButton(
      icon: Icon(Icons.visibility),
      onPressed: () {
        // Toggle password visibility
        // Implement logic to show/hide password
      },
    ),
  ),
),
SizedBox(height: 10),
Row(
  mainAxisAlignment: MainAxisAlignment.spaceBetween,
  children: [
    ElevatedButton(
      onPressed: () async {
        if (_formKey.currentState!.validate()) {
          _formKey.currentState!.save();
          // Check connectivity
          if (await isInternetConnected()) {
            // Call your shared code here
            print('Email: $_email, Password: $_password');

            // Save the email and password to Shared Preferences
            final prefs = await SharedPreferences.getInstance();
            await prefs.setString('email', _email);
            await prefs.setString('password', _password);

            // Show broadcast message
            _showBroadcastMessage('Logged in successfully!');
          } else {
            _showNoInternetDialog();
          }
        }
      },
      child: Text('Log in'),
      style: ButtonStyle(
        backgroundColor: MaterialStateProperty.all(Colors.blue),
        shape: MaterialStateProperty.all(
          RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10),
          ),
        ),
      ),
    ),
    Text('Forgot password?'),
  ],
),
SizedBox(height: 10),
Row(
  mainAxisAlignment: MainAxisAlignment.center,
  children: [
    Text('Don\'t have an account?'),
    SizedBox(width: 5),
    Text(
      'Sign up',
      style: TextStyle(color: Colors.blue),
    ),
  ],
),

// Add Google Sign-In Button
ElevatedButton(
  onPressed: () async {
    final user = await widget.googleSignInProvider.signInWithGoogle();
    if (user != null) {
      // Handle successful Google Sign-In
      print('Google Sign-In successful. User: ${user.displayName}');
    } else {
      // Handle Google Sign-In failure
      print('Google Sign-In failed.');
    }
  },
  child: Text('Sign in with Google'),
  style: ButtonStyle(
    backgroundColor: MaterialStateProperty.all(Colors.red), // Change color as needed
  ),
),
], ), ), ), ), ); }

Future<bool> isInternetConnected() async { var connectivityResult = await Connectivity().checkConnectivity(); return connectivityResult != ConnectivityResult.none; }

void _showNoInternetDialog() { showDialog( context: context, builder: (context) => AlertDialog( title: Text('No Internet Connection'), content: Text('Please check your internet connection and try again.'), actions: <Widget>[ TextButton( onPressed: () => Navigator.of(context).pop(), child: Text('OK'), ), ], ), ); }

void _showBroadcastMessage(String message) { ScaffoldMessenger.of(context).showSnackBar( SnackBar( content: Text(message), duration: Duration(seconds: 2), ), ); }

Future<void> _loadEmailPassword() async { final prefs = await SharedPreferences.getInstance(); setState(() { _email = prefs.getString('email') ?? ''; _password = prefs.getString('password') ?? ''; }); }}